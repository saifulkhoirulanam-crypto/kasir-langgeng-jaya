KASIR WARUNG LANGGENG JAYA - PAKET HOSTING
============================================

Isi paket:
- index.html              -> aplikasi utama
- manifest.webmanifest    -> agar bisa dipasang sebagai aplikasi Android
- sw.js                   -> cache/offline setelah pertama dibuka

Cara hosting:
1. Upload seluruh isi folder ini ke hosting static/HTML.
2. Pastikan index.html berada di folder utama (public root).
3. Buka alamat HTTPS hasil hosting.
4. Di Android, pilih menu browser "Tambahkan ke layar utama" / "Install app" bila tersedia.

Catatan:
- Data kasir pada versi ini disimpan di browser perangkat (localStorage).
- Gunakan menu Backup Data secara berkala.
- Untuk data yang tersinkron antar-HP/kasir, diperlukan backend/database pada versi berikutnya.
